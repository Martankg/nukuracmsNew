function close_notice(){
		$("#notice").toggle(1000);
}
function left_menu(){
		$("#left").toggle(1000);
}