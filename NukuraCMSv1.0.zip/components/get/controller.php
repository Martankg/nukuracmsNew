<?php
function com_get($config=''){
	global $_LANG;	
	
}
?>